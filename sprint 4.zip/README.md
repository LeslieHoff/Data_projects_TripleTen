https://public.tableau.com/app/profile/leslie.hoff/viz/sprintproject4/ProfitandLossregion?publish=yes

Sprint 4 project - Superstore